<?php

die('hello world');

?>